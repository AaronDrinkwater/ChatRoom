ASGE Space Invaders tutorial template code: 
Worksheet available on Blackboard for creating your Space Invaders game.